package fr.cpe.hello

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp



@Composable
fun MyList(
    items: List<MainActivity.SensorOrderList>,
    onMove: (List<MainActivity.SensorOrderList>) -> Unit
) {
//    val draggableItems by remember {
//        derivedStateOf { items.size }
//    }
    val stateList = rememberLazyListState()

    val dragDropState =
        rememberDragDropState(
            lazyListState = stateList,
            draggableItemsNum = items.size,
            onMove = { fromIndex, toIndex ->
                Log.d("ITEMS", items.joinToString { it.name })
                var newList = items.toMutableList().apply { add(toIndex, removeAt(fromIndex)) }
                onMove(newList)
//                Log.d("INDEX", "From Index $fromIndex  To index $toIndex")
//                var updatedList = items.toMutableList()
//                val itemMoving = updatedList.removeAt(fromIndex)
//                Log.d("NEW_LIST", updatedList.joinToString { it.name })

//                if (fromIndex == toIndex) return@rememberDragDropState
//                val updatedList = items.toMutableList()
//                val item = updatedList.removeAt(fromIndex)
//
////                val targetIndex = if (fromIndex < toIndex) toIndex - 1 else toIndex
//                updatedList.add(toIndex, item)
//                Log.d("NEW_LIST", updatedList.joinToString { it.name })
//                onMove(updatedList) // met à jour l'état côté parent
            })

    LazyColumn(
        modifier = Modifier.dragContainer(dragDropState),
        state = stateList,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(text = "Ordre d'affichage", fontSize = 30.sp)
        }

        draggableItems(items = items, dragDropState = dragDropState) { modifier, item ->
            Item(modifier = modifier, name = item.name)
        }

    }
}


@Composable
private fun Item(modifier: Modifier = Modifier, name: String) {
    Card(modifier = modifier) {
        Text(
            name,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
    }
}